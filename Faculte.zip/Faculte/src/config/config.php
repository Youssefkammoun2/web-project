<?php

define('DB_SERVER', 'localhost');
define('DB_USERNAME', 'root');
define('DB_PASSWORD', '');
define('DB_NAME', 'faculte_db');

// Définir l'URL de base du projet pour les redirections et les liens
// Assurez-vous que cela correspond à l'URL d'accès à votre dossier Faculte
define('BASE_URL', 'http://localhost/Faculte');

$link = mysqli_connect(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_NAME);

// Check connection
if($link === false){
    die('ERROR: Could not connect. ' . mysqli_connect_error());
}
?>
