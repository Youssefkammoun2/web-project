<?php $pageTitle = 'Se connecter - Gestion de Faculté'; include __DIR__ . '/../includes/header.php'; ?>

        <h2>Se connecter</h2>
        <?php
        if (!empty($errors)) {
            echo '<div class="alert alert-danger">';
            foreach ($errors as $error) {
                echo '<p>' . $error . '</p>';
            }
            echo '</div>';
        }
        ?>
        <form action="<?php echo BASE_URL; ?>/login.php" method="POST">
            <div class="form-group">
                <label for="email">Email :</label>
                <input type="email" id="email" name="email" class="form-control" value="<?php echo htmlspecialchars($this->user->email ?? ''); ?>" required>
            </div>
            <div class="form-group">
                <label for="mot_de_passe">Mot de passe :</label>
                <input type="password" id="mot_de_passe" name="mot_de_passe" class="form-control" required>
            </div>
            <button type="submit" class="btn btn-primary">Se connecter</button>
        </form>
        <p>Pas encore de compte ? <a href="<?php echo BASE_URL; ?>/register.php">Inscrivez-vous ici</a>.</p>

<?php include __DIR__ . '/../includes/footer.php'; ?>
