<?php $pageTitle = 'S\'inscrire - Gestion de Faculté'; include __DIR__ . '/../includes/header.php'; ?>

        <h2>S'inscrire</h2>
        <?php
        if (!empty($errors)) {
            echo '<div class="alert alert-danger">';
            foreach ($errors as $error) {
                echo '<p>' . $error . '</p>';
            }
            echo '</div>';
        }
        ?>
        <form action="<?php echo BASE_URL; ?>/register.php" method="POST">
            <div class="form-group">
                <label for="nom_utilisateur">Nom d'utilisateur :</label>
                <input type="text" id="nom_utilisateur" name="nom_utilisateur" class="form-control" value="<?php echo htmlspecialchars($this->user->nom_utilisateur ?? ''); ?>" required>
            </div>
            <div class="form-group">
                <label for="email">Email :</label>
                <input type="email" id="email" name="email" class="form-control" value="<?php echo htmlspecialchars($this->user->email ?? ''); ?>" required>
            </div>
            <div class="form-group">
                <label for="mot_de_passe">Mot de passe :</label>
                <input type="password" id="mot_de_passe" name="mot_de_passe" class="form-control" required>
            </div>
            <div class="form-group">
                <label for="confirmer_mot_de_passe">Confirmer le mot de passe :</label>
                <input type="password" id="confirmer_mot_de_passe" name="confirmer_mot_de_passe" class="form-control" required>
            </div>
            <button type="submit" class="btn btn-primary">S'inscrire</button>
        </form>
        <p>Déjà un compte ? <a href="<?php echo BASE_URL; ?>/login.php">Connectez-vous ici</a>.</p>

<?php include __DIR__ . '/../includes/footer.php'; ?>
