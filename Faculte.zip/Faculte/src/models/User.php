<?php

require_once __DIR__ . '/Database.php';

class User {
    private $conn;
    private $table_name = "utilisateurs"; // Nom de la table mis à jour

    public $id;
    public $nom_utilisateur;
    public $email;
    public $mot_de_passe;
    public $date_creation;
    // Propriétés liées à l'e-mail de vérification supprimées

    public function __construct() {
        $database = new Database();
        $this->conn = $database->getConnection();
    }

    // Enregistre un nouvel utilisateur
    public function register() {
        // Nettoyage des données
        $this->nom_utilisateur = htmlspecialchars(strip_tags($this->nom_utilisateur));
        $this->email = htmlspecialchars(strip_tags($this->email));
        $this->mot_de_passe = htmlspecialchars(strip_tags($this->mot_de_passe));

        // Hachage du mot de passe pour la sécurité
        $this->mot_de_passe = password_hash($this->mot_de_passe, PASSWORD_BCRYPT);

        // Requête d'insertion (sans le jeton de vérification d'e-mail)
        $query = "INSERT INTO " . $this->table_name . "
                  SET
                      nom_utilisateur = ?,
                      email = ?,
                      mot_de_passe = ?";

        $stmt = $this->conn->prepare($query);

        // Liaison des valeurs
        $stmt->bind_param("sss", $this->nom_utilisateur, $this->email, $this->mot_de_passe);

        // Exécution de la requête
        if($stmt->execute()) {
            return true;
        }

        return false;
    }

    // Vérifie si un nom d'utilisateur ou un e-mail existe déjà
    public function usernameOrEmailExists() {
        $query = "SELECT id FROM " . $this->table_name . " WHERE nom_utilisateur = ? OR email = ? LIMIT 0,1";

        $stmt = $this->conn->prepare($query);
        $stmt->bind_param("ss", $this->nom_utilisateur, $this->email);
        $stmt->execute();
        $stmt->store_result();

        if ($stmt->num_rows > 0) {
            return true;
        }
        return false;
    }

    // Trouve un utilisateur par son e-mail
    public function findByEmail() {
        // Ne récupère plus email_verifie_le
        $query = "SELECT id, nom_utilisateur, email, mot_de_passe FROM " . $this->table_name . " WHERE email = ? LIMIT 0,1";

        $stmt = $this->conn->prepare($query);
        $stmt->bind_param("s", $this->email);
        $stmt->execute();
        $stmt->store_result();

        if ($stmt->num_rows > 0) {
            // Ne lie plus email_verifie_le
            $stmt->bind_result($this->id, $this->nom_utilisateur, $this->email, $this->mot_de_passe);
            $stmt->fetch();
            return true;
        }
        return false;
    }

    // Vérifie un mot de passe haché
    public function verifyPassword($password) {
        return password_verify($password, $this->mot_de_passe);
    }

    // Méthode verifyEmail() supprimée
}
?>
