<?php

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Vous pouvez ajouter d'autres initialisations ici, comme la configuration de l'affichage des erreurs, etc.
// error_reporting(E_ALL);
// ini_set('display_errors', 1);

?>
