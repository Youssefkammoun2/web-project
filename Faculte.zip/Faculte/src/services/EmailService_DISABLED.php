<?php

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// Assurez-vous que PHPMailer est correctement inclus
// Si vous avez téléchargé PHPMailer manuellement et placé le dossier dans src/includes/PHPMailer,
// alors les chemins d'accès pourraient ressembler à ceci :
require_once __DIR__ . '/../includes/PHPMailer/src/Exception.php';
require_once __DIR__ . '/../includes/PHPMailer/src/PHPMailer.php';
require_once __DIR__ . '/../includes/PHPMailer/src/SMTP.php';

class EmailService {

    private $mail;

    public function __construct() {
        $this->mail = new PHPMailer(true);
        // Configuration du serveur SMTP
        $this->mail->isSMTP();
        $this->mail->Host = 'smtp.example.com'; // REMPLACEZ PAR VOTRE HÔTE SMTP
        $this->mail->SMTPAuth = true;
        $this->mail->Username = 'votre_email@example.com'; // REMPLACEZ PAR VOTRE ADRESSE E-MAIL
        $this->mail->Password = 'votre_mot_de_passe';   // REMPLACEZ PAR VOTRE MOT DE PASSE D'E-MAIL
        $this->mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS; // Utilisez ENCRYPTION_SMTPS pour SSL (port 465) ou ENCRYPTION_STARTTLS pour TLS (port 587)
        $this->mail->Port = 587; // Port SMTP (587 pour TLS, 465 pour SSL)

        // Destinataire par défaut (expéditeur)
        $this->mail->setFrom('no-reply@yourdomain.com', 'Gestion Faculté'); // REMPLACEZ PAR VOTRE ADRESSE E-MAIL ET NOM D'EXPÉDITEUR

        // Charset et format
        $this->mail->CharSet = 'UTF-8';
        $this->mail->isHTML(true);
    }

    // Envoie un e-mail de vérification
    public function sendVerificationEmail($recipientEmail, $recipientName, $verificationToken) {
        return true; // SIMULATION : l'e-mail est envoyé

        /*
        try {
            $this->mail->clearAddresses(); // Réinitialise les adresses pour chaque envoi
            $this->mail->addAddress($recipientEmail, $recipientName);

            $this->mail->Subject = 'Vérifiez votre adresse e-mail pour Gestion Faculté';
            $verificationLink = BASE_URL . "/verify_email.php?token=" . $verificationToken; // Utiliser BASE_URL
            $this->mail->Body    = "Bonjour " . htmlspecialchars($recipientName) . ",<br><br>";
            $this->mail->Body   .= "Merci de vous être inscrit à Gestion Faculté. Veuillez cliquer sur le lien ci-dessous pour vérifier votre adresse e-mail :<br><br>";
            $this->mail->Body   .= "<a href=\'" . $verificationLink . "\'>" . $verificationLink . "</a><br><br>";
            $this->mail->Body   .= "Si vous n\'avez pas créé de compte, vous pouvez ignorer cet e-mail.<br><br>";
            $this->mail->Body   .= "Cordialement,<br>L\'équipe Gestion Faculté";

            $this->mail->AltBody = "Bonjour " . htmlspecialchars($recipientName) . ",\n\n";
            $this->mail->AltBody .= "Merci de vous être inscrit à Gestion Faculté. Veuillez copier et coller le lien suivant dans votre navigateur pour vérifier votre adresse e-mail :\n\n";
            $this->mail->AltBody .= $verificationLink . "\n\n";
            $this->mail->AltBody .= "Si vous n\'avez pas créé de compte, vous pouvez ignorer cet e-mail.\n\n";
            $this->mail->AltBody .= "Cordialement,\nL\'équipe Gestion Faculté";

            $this->mail->send();
            return true;
        } catch (Exception $e) {
            error_log("Erreur lors de l\'envoi de l\'e-mail : {" . $this->mail->ErrorInfo . "}");
            return false;
        }
        */
    }
}

?>
