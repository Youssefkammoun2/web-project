<?php

require_once __DIR__ . '/../models/User.php';
// require_once __DIR__ . '/../services/EmailService.php'; // Supprimé
require_once __DIR__ . '/../config/config.php'; // Inclure config.php pour BASE_URL

class AuthController {
    private $user;
    // private $emailService; // Supprimé

    public function __construct() {
        $this->user = new User();
        // $this->emailService = new EmailService(); // Supprimé
    }

    // Affiche le formulaire d'enregistrement
    public function showRegisterForm() {
        include __DIR__ . '/../views/register.php';
    }

    // Traite la soumission du formulaire d'enregistrement
    public function register() {
        $errors = [];

        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            // Récupération et nettoyage des données du formulaire
            $this->user->nom_utilisateur = trim($_POST['nom_utilisateur']);
            $this->user->email = trim($_POST['email']);
            $password = trim($_POST['mot_de_passe']);
            $confirm_password = trim($_POST['confirmer_mot_de_passe']);

            // Validation des entrées
            if (empty($this->user->nom_utilisateur)) {
                $errors[] = "Le nom d'utilisateur est requis.";
            }

            if (empty($this->user->email)) {
                $errors[] = "L'adresse e-mail est requise.";
            } elseif (!filter_var($this->user->email, FILTER_VALIDATE_EMAIL)) {
                $errors[] = "L'adresse e-mail n'est pas valide.";
            }

            if (empty($password)) {
                $errors[] = "Le mot de passe est requis.";
            } elseif (strlen($password) < 6) {
                $errors[] = "Le mot de passe doit contenir au moins 6 caractères.";
            }

            if (empty($confirm_password)) {
                $errors[] = "Veuillez confirmer votre mot de passe.";
            } elseif ($password !== $confirm_password) {
                $errors[] = "Les mots de passe ne correspondent pas.";
            }

            // Vérifier si le nom d'utilisateur ou l'e-mail existe déjà
            if ($this->user->usernameOrEmailExists()) {
                $errors[] = "Ce nom d'utilisateur ou cette adresse e-mail est déjà utilisée.";
            }

            // Si aucune erreur, tenter d'enregistrer l'utilisateur
            if (empty($errors)) {
                $this->user->mot_de_passe = $password;
                if ($this->user->register()) {
                    // L'enregistrement a réussi, rediriger directement vers la page de connexion
                    header("Location: " . BASE_URL . "/login.php?registration=success"); // Rediriger directement
                    exit();
                } else {
                    $errors[] = "Une erreur est survenue lors de l'enregistrement. Veuillez réessayer.";
                }
            }
        }
        // Si la méthode n'est pas POST ou s'il y a des erreurs, réafficher le formulaire
        include __DIR__ . '/../views/register.php';
    }

    // Méthode verifyEmail() supprimée
    // public function verifyEmail() { ... }

    // Affiche le formulaire de connexion
    public function showLoginForm() {
        include __DIR__ . '/../views/login.php';
    }

    // Traite la soumission du formulaire de connexion
    public function login() {
        $errors = [];

        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $this->user->email = trim($_POST['email']);
            $password = trim($_POST['mot_de_passe']);

            if (empty($this->user->email)) {
                $errors[] = "L'adresse e-mail est requise.";
            }

            if (empty($password)) {
                $errors[] = "Le mot de passe est requis.";
            }

            if (empty($errors)) {
                if ($this->user->findByEmail()) {
                    if ($this->user->verifyPassword($password)) {
                        // Connexion réussie, créer une session (pas de vérification d'e-mail)
                        $_SESSION['utilisateur_id'] = $this->user->id;
                        $_SESSION['nom_utilisateur'] = $this->user->nom_utilisateur;
                        header("Location: " . BASE_URL . "/dashboard.php"); // Rediriger vers le tableau de bord
                        exit();
                    } else {
                        $errors[] = "Mot de passe incorrect.";
                    }
                } else {
                    $errors[] = "Aucun compte trouvé avec cette adresse e-mail.";
                }
            }
        }
        include __DIR__ . '/../views/login.php';
    }

    // Déconnecte l'utilisateur
    public function logout() {
        $_SESSION = array();
        session_destroy();
        header("Location: " . BASE_URL . "/login.php");
        exit();
    }
}
?>
