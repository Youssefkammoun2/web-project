<?php

require_once __DIR__ . '/src/includes/init.php'; // Inclure le fichier d'initialisation
require_once __DIR__ . '/src/controllers/AuthController.php';
require_once __DIR__ . '/src/config/config.php'; // Inclure config.php pour BASE_URL

$authController = new AuthController();

$request_uri = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
$base_path = '/Faculte'; // Adaptez ceci à votre chemin de dossier XAMPP

// Retirez le chemin de base pour obtenir le chemin relatif
// La logique de $base_path reste ici pour la détection initiale de la route
if (strpos($request_uri, $base_path) === 0) {
    $request_uri = substr($request_uri, strlen($base_path));
}

// Définition des routes
switch ($request_uri) {
    case '/register.php':
        $authController->register();
        break;
    case '/login.php':
        $authController->login();
        break;
    case '/logout.php':
        $authController->logout();
        break;
    case '/dashboard.php':
        // TODO: Implémenter le tableau de bord
        if (!isset($_SESSION['utilisateur_id'])) {
            header("Location: " . BASE_URL . "/login.php"); // Utiliser BASE_URL
            exit();
        }
        echo "Bienvenue sur votre tableau de bord, " . htmlspecialchars($_SESSION['nom_utilisateur']) . "!";
        break;
    case '/':
    case '':
        // Redirection par défaut vers la page de connexion
        header("Location: " . BASE_URL . "/login.php"); // Utiliser BASE_URL
        exit();
    default:
        http_response_code(404);
        echo "Page non trouvée.";
        break;
}

?>
